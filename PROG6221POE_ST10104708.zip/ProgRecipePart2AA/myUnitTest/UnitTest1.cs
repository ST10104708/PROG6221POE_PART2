
namespace myUnitTest
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test1()
        {
            // Arrange
            var recipe = new Recipe("Test Recipe");

            var ingredient1 = new Ingredient
            {
                Name = "Ingredient 1",
                Quantity = 2,
                Unit = "cups",
                Calories = 100,
                FoodGroup = "Group A"
            };
            recipe.AddIngredient(ingredient1);

            var ingredient2 = new Ingredient
            {
                Name = "Ingredient 2",
                Quantity = 1,
                Unit = "tablespoon",
                Calories = 50,
                FoodGroup = "Group B"
            };
            recipe.AddIngredient(ingredient2);

            // Act
            var totalCalories = recipe.CalculateTotalCalories();

            // Assert
            Assert.AreEqual(250, totalCalories);

        }
    }
}